UPShost = '127.0.0.1'
Webhost = '127.0.0.2'
worldhost = '152.3.53.20'
worldport = 23456
worldaddr = (worldhost, worldport)

def listen_for_world(worldsocket, UPSsocket):
    while True:
        print("Recv response from world:")
        whole_message = recv_response(worldsocket)
        response = amazon_pb2.AResponse()
        response.ParseFromString(whole_message)
        # create a thread and handle
        handler = threading.Thread(target = handle_world_reqeust, args = (response, worldsocket, UPSsocket))
        handler.start()
        # handle_world_reqeust(response, worldsocket, UPSsocket)

def listen_for_UPS(worldsocket, UPSsocket):
    while True:
        print("Recv response from UPS:")
        whole_message = recv_response(UPSsocket)
        response = commu_pb2.UCommunicate()
        response.ParseFromString(whole_message)
        # create a thread and handle
        handler = threading.Thread(target = handle_UPS_reqeust, args = (response, worldsocket, UPSsocket))
        handler.start()
        # handle_UPS_reqeust(response, worldsocket, UPSsocket)


def listen_for_web(proxysocket, worldsocket, UPSsocket):
    while True:
        tcpServer.listen(4)
        # print "Multithreaded Python server : Waiting for connections from TCP clients..."
        (websocket, (ip,port)) = tcpServer.accept()
        print("connected")
        # recv request from front end
        message = recv_response(websocket)
        request = commu_pb2.ACommunicate()
        request.ParseFromString(message)
        print(request)
        # create a thread and handle
        handler = threading.Thread(target = handle_web_reqeust, args = (response, worldsocket, UPSsocket))
        handler.start()
        # handle_web_request(request, worldsocket, UPSsocket)

def handle_world_request(request, worldsocket, UPSsocket):
    ap = AResponseParser(request)
    ap.update_status()
    acommunicate = ap.generateAloadingFinished()
    send_request(UPSsocket, acommunicate)
     
def handle_UPS_reqeust(request, worldsocket, UPSsocket):
    up = UPSParser(request)
    up.associate_tid_pid()
    acommand = up.get_APutOnTruck()
    send_request(worldsocket, accomand)

def handle_web_request(request, worldsocket, UPSsocket):
    wp = WebRequestParser(request)
    if wp.isBuy():
        wp.getAPurchaseMore(0)
        wp.getAPack(1)
        wp.getAOrderPlaced(2)
        print("ACommands")
        print(wp.getACommands())
        print("UCommunicates")
        print(wp.getUCommunicate())
        send_request(worldsocket, wp.getACommands)
        send_request(UPSsocket, wp.getUCommunicate)
    else:
        pass
    

def send_request(sock, request):
    """Send protocol buffer over connected socket
    
    Args:
        request -- a protocol buffer
    """
    message = request.SerializeToString()
    _EncodeVarint(sock.send, len(message), None)
    sock.sendall(message)
        

def recv_response(sock):
    """Return a protocol buffer over connected socket
    """
    var_int_buff = []
    count = 0

    while True:     # get the length of the message
        try:
            count += 1
            buf = sock.recv(1)
            var_int_buff += buf
            # print("Buff has size " + str(len(var_int_buff)))
            # msg_len, new_pos = _DecodeVarint32(var_int_buff, 0)
            # if new_pos != 0:
            #     break
            
            msg_len, new_pos = _DecodeVarint32(var_int_buff, 0)
            if new_pos != 0:
                break
        except:
            continue
    print(msg_len)
    whole_message = sock.recv(msg_len)
    # response = amazon_pb2.AConnected()
    # response.ParseFromString(whole_message)
    return whole_message

class WebProxy:
    """Web proxy server responsible for interaction with world

    set up a socket listening for connection from web
    parse Acommands from web
    generate Acommands to the world and send to world

    generate UCommunicate for UPSProxy
    """
    def __init__(self, host = '', port = 5678):
        """initialize host and port for UPS and Web connection
        """
        self.host = host
        self.port = port
        self.worldhost = worldhost
        self.UPSconn = None
        self.Webconn = None # check if it is None
        self.connect_to_world()
        self.connect_to_UPS()

    def run():
        worldhandler = threading.Thread(target=listen_for_world, args=(self.worldsocket, self.UPSsocket))
        worldhandler.start()
        UPShandler = threading.Thread(target=listen_for_UPS, args=(self.worldsocket, self.UPSsocket))
        UPShandler.start()
        webhandler = threading.Thread(target=listen_for_web, args=(self.proxysocket, self.worldsocket, self.UPSsocket))
        webhandler.start()


    def connect_to_UPS(self):
        self.proxyserver = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.proxyserver.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.proxyserver.bind((self.host, self.port))
        self.proxyserver.listen()
        while True:
            (self.UPSsocket, (ip,port)) = self.proxyserver.accept()
            break
            # if ip == UPShost:
            #     self.UPSconn = conn
            #     print('UPS connected by', (ip, port))
            #     break
        # elif ip == Webhost:
        #     self.Webconn = conn 
        #     print('Web connected by', (ip, port))

    def wait_for_connection(self):
        """wait for UPS connection

        update UPS connection and use the latest one to communicate
        """
        
        (conn, (ip,port)) = self.amazonserver.accept()
        if ip == UPShost:
            self.UPSconn = conn
            print('UPS connected by', (ip, port))
        elif ip == Webhost:
            self.Webconn = conn 
            print('Web connected by', (ip, port))


    def connect_to_Web(self):
        """wait for WEB connection
        """
        


    def connect_to_world(self, addr):
        self.worldsocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.worldsocket.connect(addr)

        request = amazon_pb2.AConnect()
        request.worldid = 1
        request.isAmazon = True
        print(request)
        send_request(self.worldsocket, request)

        while True:
            whole_message = recv_response(self.worldsocket)
            response = amazon_pb2.AConnected()
            try:
                response.ParseFromString(whole_message)
            except:
                continue        
            print(response)
            print("World id is %d" % response.worldid)
            break




    def handle_web_request(self):
        """Recv Acommands from web, parse them and reforwarding to 
        world
        """

class ClientThread(threading.Thread):
    def __init__(self, s, job, addr):
        threading.Thread.__init__(self)
        self.s = s
        self.job = job
        self.addr = addr
        

    def run(self):
        worldclient = WorldClient(self.addr, self.s)
        jobdict = {
            "send": worldclient.send_request,
            "recv": worldclient.recv_response,
            # "listen": worldclient.listen_response
        }
        jobdict[job]()
        # funclist = [client.connect_world, client.test_purchase, client.test_pack, client.test_query, client.listen_response]
        # funclist = [client.connect_world]
        # if self.i != 0:
            # time.sleep(5)
        # if self.i == 4:
        #     time.sleep(5)
        # funclist[self.i]()


class WorldClient:
    def __init__(self, addr, sock):
        self.addr = addr
        self.sock = sock


    def send_request(self, request):
        """Send protocol buffer over connected socket
        
        Args:
            request -- a protocol buffer
        """
        message = request.SerializeToString()
        _EncodeVarint(self.sock.send, len(message), None)
        while True:
            try:
                self.sock.sendall(message)
            except socket.error as e:           # broken connection
                self.sock.connect(self.addr)
                continue
            else:
                break

    def recv_response(self):
        """recv message from world

        Return byte string as result
        """
        var_int_buff = []
        count = 0

        while True:     # get the length of the message
            try:
                count += 1
                buf = self.sock.recv(1)
                var_int_buff += buf
                
                msg_len, new_pos = _DecodeVarint32(var_int_buff, 0)
                if new_pos != 0:
                    break
            except socket.error:                # broken connection
                self.sock.connect(self.addr)
                continue
        print(msg_len)
        whole_message = self.sock.recv(msg_len)
        # response = amazon_pb2.AConnected()
        # response.ParseFromString(whole_message)
        return whole_message

def main():
    wp = WebProxy()
    wp.connect_to_world()

import amazon_pb2

class AResponseParser:
    def __init__(self, aresponse):
        self.aresponse = aresponse

    def get_seqnum(self):
        seqlist = []
        for i in self.aresponse.arrived:
            seqlist.append(i.seqnum)
        for i in self.aresponse.ready:
            seqlist.append(i.seqnum)
        for i in self.aresponse.loaded:
            seqlist.append(i.seqnum)
        for i in self.aresponse.error:
            seqlist.append(i.seqnum)
        for i in self.aresponse.packagestatus:
            seqlist.append(i.seqnum)

        return seqlist

    def get_ack(self):
        acklist = []
        for i in self.aresponse.acks:
            acklist.append(i)

        return acklist

    def get_package_status(self):
        statuslist = []
        for i in self.aresponse.packagestatus:
            statuslist.append([i.packageid, i.status])

        return statuslist

    def update_status(self):
        statustable = {}
        for ready in self.aresponse.ready:
            statustable[ready.shipid] = 'packed'
            # statuslist.append((ready.shipid, 'packed'))

        for loaded in self.aresponse.loaded:
            statustable[loaded.shipid] = 'loaded'
            # statuslist.append((loaded.shipid, 'loaded'))

        for packagestatus in self.aresponse.packagestatus:
            if packagestatus.shipid not in statustable:
                statustable[packagestatus.shipid] = packagestatus.status

        update_status_DB(statustable)

    def generate_ALoadingFinished(self):
        ac = commu_pb2.ACommunicate()

        loadlist = []
        for loaded in self.aresponse.loaded:
            pckid = loaded.shipid
            truckid = get_truckid_from_DB(pckid)
            loadlist.append((truckid, pckid))
        add_ALoadingFinished(loadlist, ac)

        return ac

def update_status_DB(statustable):
    try:
        connection = psycopg2.connect(user="postgres",
                                      password="passw0rd",
                                      host="152.3.53.20",
                                      port="5432",
                                      database="postgres")
        cursor = connection.cursor()
        for pckid, status in statustable:
            postgreSQL_update_Query = """update order_orders set status = %s where shipid = %s"""
            # postgreSQL_update_Query = "'" + status + "' where "shipId" = '" + str(pckid) + "'"
            cursor.execute(postgreSQL_select_Query, [(status, str(pckid))])

    except (Exception, psycopg2.Error) as error :
        print ("Error while fetching data from PostgreSQL", error)
    
    finally:
        #closing database connection.
        if(connection):
            cursor.close()
            connection.close()
            print("PostgreSQL connection is closed")

def add_ALoadingFinished(loadlist, ac):
    for truckid, pckid in loadlist:
        aloaded = ac.aloaded.add()
        aloaded.packageid = pckid
        aloaded.truckid = truckid
        aloaded.seqnum = pckid * 10 + 2


def get_truckid_from_DB(pckid):
    try:
        connection = psycopg2.connect(user="postgres",
                                      password="passw0rd",
                                      host="152.3.53.20",
                                      port="5432",
                                      database="postgres")
        cursor = connection.cursor()
        postgreSQL_select_Query = 'select "truckId" from order_truck where "shipId" = ' + str(pckid)
        cursor.execute(postgreSQL_select_Query)
        print("Selecting packageid from wareHouse table using cursor.fetchall")
        records = cursor.fetchall()

        print("Print each row and it's columns values")
        truckid = None
        for row in records:
            truckid = row[0]
        # postgreSQL_delete_Query = 'delete from order_truck where "truckId" = ' + truckid
        cursor.execute(postgreSQL_delete_Query)


       
    except (Exception, psycopg2.Error) as error :
        print ("Error while fetching data from PostgreSQL", error)
    
    finally:
        #closing database connection.
        if(connection):
            cursor.close()
            connection.close()
            print("PostgreSQL connection is closed")
            return truckid

class AResponseParserTest:
    def __init__(self):
        pass

    def test(self):
        response = amazon_pb2.AResponses()
        
        arr = response.arrived.add()
        arr.whnum = 1
        arr.seqnum = 1

        ready = response.ready.add()
        ready.shipid = 1
        ready.seqnum = 2

        loaded = response.loaded.add()
        loaded.shipid = 1
        loaded.seqnum = 3

        error = response.error.add()
        error.err = "Testing Error"
        error.originseqnum = 0
        error.seqnum = 4

        response.acks.append(-1)

        packagestatus = response.packagestatus.add()
        packagestatus.packageid = 1
        packagestatus.status = "On my way"
        packagestatus.seqnum = 5

        parser = AResponseParser(response)
        # print(parser.get_seqnum())
        # print(parser.get_ack())
        # print(parser.get_package_status())
        print_my(parser.get_seqnum())
        print_my(parser.get_ack())
        print_my(parser.get_package_status())

def print_my(alist):
    for i in alist:
        print(type(i))
        if (isinstance(i, list)):
            for j in i:
                print(type(j))
def main():
    testor = AResponseParserTest()
    testor.test()

if __name__ == '__main__':
    main()